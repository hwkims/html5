# RurimoOnlineClient
RurimoOnlineClient based on RMXP.<br>

## Environment Config
https://rurimo.github.io/RurimoOnlineClient/

## Commit Rule
내부적으로 scripts를 수정했다면, 커밋하기 전에 [gemini-editor](https://sourceforge.net/projects/geminieditor/)를 사용하여 반드시 root 프로젝트의 scripts 폴더로 export하여 수정 사항을 반영한다.


