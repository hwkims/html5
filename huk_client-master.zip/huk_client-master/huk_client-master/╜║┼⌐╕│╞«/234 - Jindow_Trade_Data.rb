class Jindow_Trade_Data
	attr_accessor :id
	attr_accessor :type
	attr_accessor :amount
	attr_accessor :is_ok
	
	@is_ok = false
end