class Game_Party
	attr_accessor :items
	attr_accessor :weapons
	attr_accessor :armors
end