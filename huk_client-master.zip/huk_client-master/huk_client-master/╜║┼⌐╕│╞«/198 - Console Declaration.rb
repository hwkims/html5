#$console = Console.new(400, 200, 280, 146, 8)
#$console.show

