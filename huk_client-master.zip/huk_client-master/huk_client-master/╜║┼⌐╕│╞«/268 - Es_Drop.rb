class Drop
	attr_accessor :id
	attr_accessor :type
	attr_accessor :type2
	attr_accessor :amount
end