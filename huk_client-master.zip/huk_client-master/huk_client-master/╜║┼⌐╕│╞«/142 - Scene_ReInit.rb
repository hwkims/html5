class Scene_Reinit
	def main
		$scene = Scene_Map.new
	end
end