class Jindow_Temp
	
	attr_accessor :inven
	
	def initialize
		@inven = Rect.new(203, 122, 640, 480)
		@status = Rect.new(0, 0, 0, 0)
		@equip = Rect.new(0, 0, 0 , 0)
	end
end
